# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['page_loader']
install_requires = \
['pytest-cov>=3.0.0,<4.0.0', 'requests>=2.27.1,<3.0.0']

entry_points = \
{'console_scripts': ['page-loader = scripts.page_loader:driver']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'First page loader with tests',
    'long_description': None,
    'author': 'konstter',
    'author_email': 'konst.br@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'py_modules': modules,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
